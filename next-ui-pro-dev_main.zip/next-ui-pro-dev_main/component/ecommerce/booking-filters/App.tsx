import React from "react";

import FiltersWrapper from "./filters-wrapper";
import bookingItems from "./booking-items";

export default function Component() {
  return <FiltersWrapper items={bookingItems} />;
}
